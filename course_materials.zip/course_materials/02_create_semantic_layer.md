Create a semantic layer for the raw database: `data/agile_issues.db`.

Use the template in `templates/tmp_semantic_layer.yml` and store the output as `semantic_layer.yml` in the same directory as the database.

This semantic layer must support multiple analytical questions. Do not design it specifically for release v2.4 or for forecasting.

The following governed definitions are valid:

1. **Canonical IDs**

   * The business key is `issue_key`.
   * There must be one canonical record per `issue_key`.
   * If duplicate records exist, retain the record with the greatest `updated` timestamp. Break ties using the greatest `id`.

2. **Release**

   * Release membership is defined by the trimmed value of `issues.fix_version`.
   * Null or blank release values remain unassigned. Do not infer them.

3. **Delivery state**

   * `delivered`: `resolution = "Done"` and `resolved` is present.
   * `excluded`: `resolution` is either `"Won't Do"` or `"Duplicate"`.
   * `remaining`: neither delivered nor excluded.
   * For event-time calculations, a resolution only applies when `resolved` is on or before the requested `as_of_date`.

4. **Story points**

   * Trim surrounding whitespace and parse valid numeric values.
   * Blank strings, `?`, `TBD`, and unparseable values become null.
   * Never impute missing story points.
   * Negative values are invalid.

5. **Issue count**

   * Count distinct canonical `issue_key` values after applying the requested filters.
   * Include a parameterized SQLite query for this metric directly in its YAML definition.

6. **Delivered issue count**

   * Count canonical issues in the governed `delivered` state.
   * Include a parameterized SQLite query for this metric directly in its YAML definition.

7. **Excluded and remaining issue counts**

   * Apply the governed delivery-state definitions.
   * Include separate parameterized SQLite queries for `excluded_issue_count` and `remaining_issue_count`.

8. **Weekly throughput**

   * Count distinct delivered issues by the calendar week of `resolved`.
   * Weeks run Monday through Sunday.
   * Include only complete weeks ending on or before `as_of_date`.
   * Include a parameterized SQLite query for this metric directly in its YAML definition.

9. **Estimate coverage**

   * Divide canonical issues with valid normalized story points by all eligible canonical issues under the same filters.
   * The result is a ratio from 0 to 1.
   * It must support filtering by delivery state, release, issue type, priority, and sprint.
   * Include a parameterized SQLite query for this metric directly in its YAML definition.

For other concepts:

* Map straightforward source fields and describe their meaning.
* Put agent-suggested dimensions or metrics under `proposed_additions`.
* Keep their `definition_status` as `proposed`.
* Include SQL for proposed metrics, but do not treat that SQL as governed.
* Do not treat a proposed definition as governed without human approval.
* Ask me if a business definition is genuinely ambiguous and is not resolved above.

SQL requirements:

* Store metric SQL directly inside the corresponding YAML metric definition.
* Set the SQL dialect to `sqlite`.
* Use named parameters such as `:as_of_date` and `:release`.
* Use only read-only `SELECT` statements and common table expressions.
* Do not use `CREATE`, `INSERT`, `UPDATE`, `DELETE`, `ALTER`, `DROP`, or other data-changing statements.

Rules:

* The only file you may create or modify is `semantic_layer.yml`.
* Do not modify the raw database.
* Do not create prepared tables, views, extracts, or datasets.
* Do not create notebooks, Python files, scripts, or analytical reports.
* You may run read-only queries to inspect the source and validate the embedded SQL, but do not persist their results.

When finished:

1. Validate the generated YAML against the template structure.
2. Validate that each governed metric contains syntactically valid read-only SQLite SQL.
3. Confirm that the raw database checksum is unchanged.
4. Report which definitions are governed, which additions are proposed, and any unresolved blockers.
